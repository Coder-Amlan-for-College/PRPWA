const int STEP_PIN = 3;
const int DIR_PIN = 4;
const int ENABLE_PIN = 5;

const int STEPS=100;
const int STEP_DELAY=1000;

void moveSteps(int steps,bool clockwise){
  digitalWrite(DIR_PIN,clockwise?HIGH:LOW);
  for(int i=0;i<steps;i++){
    digitalWrite(STEP_PIN, HIGH);
    delayMicroseconds(STEP_DELAY);
    digitalWrite(STEP_PIN,LOW);
    delayMicroseconds(STEP_DELAY);
  }
} 
void setup() {
  // put your setup code here, to run once:
   pinMode(STEP_PIN,OUTPUT);
   pinMode(DIR_PIN, OUTPUT);
   pinMode(ENABLE_PIN, OUTPUT);
   digitalWrite(ENABLE_PIN, LOW);
}

void loop() {
  // put your main code here, to run repeatedly:
   moveSteps(50,true);
   delay(1000);
   moveSteps(50,true);
   delay(1000);
}
